﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RETO1_EDIFICIO
{
    internal class Program
    {
        static void Main(string[] args)
        {

            int[] personas = new int[5];
            int[] niveles = new int[5];
            int v, max = personas[0], min = personas[0];
            int x, maximo = niveles[0], minimo = niveles[0];
            for (int i = 0; i < 1; i++)
            {
                Console.Write("Ingrese la cantidad de personas en el nivel 1: ");
                v = int.Parse(Console.ReadLine());
                personas[i] = v;
                niveles[i] = v;
            }
            for (int i = 1; i < 2; i++)
            {
                Console.Write("Ingrese la cantidad de personas en el nivel 2: ");
                v = int.Parse(Console.ReadLine());
                personas[i] = v;
                niveles[i] = v;
            }
            for (int i = 2; i < 3; i++)
            {
                Console.Write("Ingrese la cantidad de personas en el nivel 3: ");
                v = int.Parse(Console.ReadLine());
                personas[i] = v;
                niveles[i] = v;
            }
            for (int i = 3; i < 4; i++)
            {
                Console.Write("Ingrese la cantidad de personas en el nivel 4: ");
                v = int.Parse(Console.ReadLine());
                personas[i] = v;
                niveles[i] = v;
            }
            for (int i = 4; i < 5; i++)
            {
                Console.Write("Ingrese la cantidad de personas en el nivel 5: ");
                v = int.Parse(Console.ReadLine());
                personas[i] = v;
                niveles[i] = v;
            }
            if (personas[0] > personas[1] && personas[0] > personas[2] && personas[0] > personas[3] && personas[0] > personas[4])
                   Console.WriteLine("El nivel 1 contien mayor cantidad de personas");
           else if(     personas[1] > personas[0] && personas[1] > personas[2] && personas[1] > personas[3] && personas[1] > personas[4])
                   Console.WriteLine("El nivel 2 contien mayor cantidad de personas");
           else if(     personas[2] > personas[0] && personas[2] > personas[1] && personas[2] > personas[3] && personas[2] > personas[4])
                   Console.WriteLine("El nivel 3 contien mayor cantidad de personas");
            else if(    personas[3] > personas[0] && personas[3] > personas[1] && personas[3] > personas[3] && personas[3] > personas[4])
                   Console.WriteLine("El nivel 4 contien mayor cantidad de personas");
            else if(    personas[4] > personas[0] && personas[4] > personas[1] && personas[4] > personas[3] && personas[4] > personas[4])
                   Console.WriteLine("El nivel 5 contien mayor cantidad de personas");
            Console.ReadLine();
        }
    }
}